Altere a Senha aqui
<a href="dashboard.html">Voltar</a>