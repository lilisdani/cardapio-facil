<<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos em Tempo Real</title>
    <style>
        /* Estilos CSS opcionais */
    </style>
</head>
<body>
    <h1>Pedidos em Tempo Real</h1>
    <div id="pedidos"></div>

    <script src="script.js"></script>
</body>
</html>










